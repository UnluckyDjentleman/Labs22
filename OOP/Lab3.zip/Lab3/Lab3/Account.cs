﻿using System;
using System.Runtime.Serialization.Json;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;

namespace Lab3
{
    [DataContract]
    public class Account
    {
        [DataMember]
        [StringLength(10)]
        public string MyAcc { get; set; }//acc number
        [DataMember]
        public string TypeVkl { get; set; }//type of vklad
        [DataMember]
        [Range(0.0,99999999.9,ErrorMessage ="Sum must be bigger than 0 or lower than 100000000")]
        public double Balance { get; set; }//balance
        [DataMember]
        public string Datetime { get; set; }//Date
        [DataMember]
        public string IsSMS { get; set; }//Is SMS - notifications connected
        [DataMember]
        public string IsConnectInternet { get; set; }//IS Internet banking connected
        [DataMember]
        public Master MasterOfPuppets;
        public Account(string myAcc, string typeVkl, double balance, string dateTime, string isSMS, string isConnectInternet, Master master)
        {
            MyAcc = myAcc;
            TypeVkl = typeVkl;
            Balance = balance;
            Datetime = dateTime;
            IsSMS = isSMS;
            IsConnectInternet = isConnectInternet;
            MasterOfPuppets = master;
        }
        public Account()
        {
            MyAcc = "";
            TypeVkl = "";
            Balance = 0.0;
            Datetime = "";
            IsSMS = "";
            IsConnectInternet = "";
            MasterOfPuppets = new Master();
        }
    }
}
