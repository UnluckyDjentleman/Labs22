﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            Text = "Search by balance";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var el in ListOfAccounts.accounts)
            {
                if (Convert.ToDouble(textBox1.Text) == el.Balance)
                {
                    MessageBox.Show($"Name:{el.MasterOfPuppets.Name}\nSurname:{el.MasterOfPuppets.Surname}\n" +
                        $"Date Of Birth:{el.MasterOfPuppets.DateOfBirth}\nID:{el.MasterOfPuppets.PasswordNumber}\n" +
                        $"Contribution:{el.TypeVkl}\nBalance:{el.Balance}$\nSMS-Notification:{el.IsSMS}\nInternet-banking:{el.IsConnectInternet}\n" +
                        $"Number:{el.MyAcc}", $"{el.MasterOfPuppets.Name} {el.MasterOfPuppets.Surname}");
                    SearchedByBalance.searchByBalance.Add(el);
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
