﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    static class ListOfAccounts
    {
        public static List<Account> accounts = new List<Account>();
    }
    static class SearchedByNameSurname
    {
        public static List<Account> searchByNameSurname = new List<Account>();
    }
    static class SearchedByBalance
    {
        public static List<Account> searchByBalance = new List<Account>();
    }
    static class SearchedByContribution
    {
        public static List<Account> searchByContribution = new List<Account>();
    }
}
