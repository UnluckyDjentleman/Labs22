﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Lab3
{
    [DataContractAttribute]
    public class Master
    {
        [DataMember]
        [RegularExpression(@"^[A-Z][a-z]+(-'[A-Z][a-z]+)?$",ErrorMessage ="Wrong name")]
        public string Name { get; set; }
        [DataMember]
        [RegularExpression(@"^[A-Z][a-z]+(-'[A-Z][a-z]+)?$", ErrorMessage = "Wrong surname")]
        public string Surname { get; set; }
        [DataMember]
        public string DateOfBirth { get; set; }
        [DataMember]
        [IDAttribute]
        public string PasswordNumber { get; set; }
        public Master(string name, string surname, string dateOfBirth, string passwordNum)
        {
            Name = name;
            Surname = surname;
            DateOfBirth = dateOfBirth;
            PasswordNumber = passwordNum;
        }
        public Master() { }
    }
    public class IDAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            Regex regexPasswordID = new Regex(@"^([0-9]{7})+[A-Z]+([0-9]{3})+([A-Z]{2})+[0-9]");
            if(value is string idp)
            {
                Match matchingID = regexPasswordID.Match(idp);
                if (matchingID.Success)
                {
                    return true;
                }
                else
                {
                    ErrorMessage = "Wrong ID";
                    MessageBox.Show(ErrorMessage);
                }
            }
            return false;
        }
    }
}
