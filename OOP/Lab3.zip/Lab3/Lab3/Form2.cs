﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            Text = "Search by name and surname";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            SearchedByNameSurname.searchByNameSurname.Clear();

            var result = ListOfAccounts.accounts.Where(x => x.MasterOfPuppets.Name == textBox1.Text && x.MasterOfPuppets.Surname == textBox2.Text);
            SearchedByNameSurname.searchByNameSurname.AddRange(result);

            foreach (var el in result)
            {
                    MessageBox.Show($"Name:{el.MasterOfPuppets.Name}\nSurname:{el.MasterOfPuppets.Surname}\n" +
                        $"Date Of Birth:{el.MasterOfPuppets.DateOfBirth}\nID:{el.MasterOfPuppets.PasswordNumber}\n" +
                        $"Contribution:{el.TypeVkl}\nBalance:{el.Balance}$\nSMS-Notification:{el.IsSMS}\nInternet-banking:{el.IsConnectInternet}\n" +
                        $"Number:{el.MyAcc}", $"{el.MasterOfPuppets.Name} {el.MasterOfPuppets.Surname}");                    
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
