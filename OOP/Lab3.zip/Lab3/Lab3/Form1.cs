﻿using System;
using System.Text.RegularExpressions;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Xml.Serialization;
using System.Text.Json;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;

namespace Lab3
{
    public partial class Form1 : Form
    {
        public int counter = 0;
        public Form1()
        {
            InitializeComponent();
            Text = "Main page";
            Timer timer = new Timer();
            timer.Enabled = true;
            timer.Tick += new EventHandler(Tickle);
            void Tickle(object sender,EventArgs e)
            {
                dateTimeNow.Text = DateTime.Now.ToString("yyyy.MM.dd, HH.mm.ss");
            }
            actions.Text = "";
            toolStripLabel1.Text = "0 object(s)";
        }
        Account emptyAcc = new Account();
        Stack<Account> listUR = new Stack<Account>();
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Author: Vlad Goroshchenya (I'm a lame)\nVersion:{Assembly.GetExecutingAssembly().GetName().Version}");
            actions.Text = "About me (nothing special)";
        }
        IEnumerable<Account> sortedByDate1 = ListOfAccounts.accounts.OrderBy(n => n.Datetime);
        private void dateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "Sorted By Date";
            foreach(var el in sortedByDate1)
            {
                form5.textBox1.Text += $"------------------------------------\r\nName:{el.MasterOfPuppets.Name}\r\nSurname:{el.MasterOfPuppets.Surname}\r\nDate Of Birth:{el.MasterOfPuppets.DateOfBirth}\r\nID:{el.MasterOfPuppets.PasswordNumber}\r\nContribution:{el.TypeVkl}\r\nBalance:{el.Balance}\r\nSMS-Notification:{el.IsSMS}\r\nInternet-banking:{el.IsConnectInternet}\nNumber:{el.MyAcc}\r\n------------------------------------\r\n";
            }
            form5.Show();
            actions.Text = "Sort By Date";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string iSMS = "";
            string iBank = "";
                string dOB = dateTimePicker1.Value.Day.ToString() + "." + dateTimePicker1.Value.Month.ToString() + "." + dateTimePicker1.Value.Year.ToString();
                string dOO = dateTimePicker2.Value.Day.ToString() + "." + dateTimePicker2.Value.Month.ToString() + "." + dateTimePicker2.Value.Year.ToString();
                if (IB.GetItemChecked(0))
                {
                    iBank = IB.Items[0].ToString();
                }
                else if (IB.GetItemChecked(1))
                {
                    iBank = IB.Items[1].ToString();
                }
                if (checkedListBox1.GetItemChecked(0))
                {
                    iSMS = checkedListBox1.Items[0].ToString();
                }
                else if (checkedListBox1.GetItemChecked(1))
                {
                    iSMS = checkedListBox1.Items[1].ToString();
                }
            var res = new List<ValidationResult>();
            var result= new List<ValidationResult>();
            var context = new ValidationContext(emptyAcc);
            Master dungeonMaster = new Master(textBox1.Text, textBox2.Text, dOB, textBox3.Text);
            var cont = new ValidationContext(dungeonMaster);
            if (Validator.TryValidateObject(dungeonMaster, cont, result, true))
            {
                if (Validator.TryValidateObject(emptyAcc, context, res, true))
                {
                    emptyAcc = new Account(textBox6.Text, comboBox1.Text, Convert.ToDouble(textBox4.Text),
                        dOO,
                        iSMS, iBank, dungeonMaster);
                    ListOfAccounts.accounts.Add(emptyAcc);
                    MessageBox.Show("Congratulations! Your account is valid and info added to object!", "Accounts");
                    counter++;
                }
                else
                {
                    foreach (ValidationResult resus in res)
                        MessageBox.Show(resus.ErrorMessage);
                }
            }
            else
            {
                foreach (ValidationResult resus1 in result)
                    MessageBox.Show(resus1.ErrorMessage);
            }
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox6.Text = "";
                comboBox1.Text = "";
                dateTimePicker1.Value = DateTime.Now;
                dateTimePicker2.Value = DateTime.Now;
                foreach (int i in IB.CheckedIndices)
                {
                    IB.SetItemCheckState(i, CheckState.Unchecked);
                }
                foreach (int i in checkedListBox1.CheckedIndices)
                {
                    checkedListBox1.SetItemCheckState(i, CheckState.Unchecked);
                }
            toolStripLabel1.Text = ListOfAccounts.accounts.Count.ToString() + " object(s)";
            actions.Text = "Add Info";
        }
        private void nameSurnameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            actions.Text = "Searching by Name/Surname";
        }

        private void xMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XmlSerializer formatter = new XmlSerializer(typeof(List<Account>));
            using (FileStream fs = new FileStream("AccountsSortedByContribution.xml", FileMode.Create))
            {
                formatter.Serialize(fs, sortedByDate.ToList());
            }
            using (FileStream fs = new FileStream("AccountsSortedByDate.xml", FileMode.Create))
            {
                formatter.Serialize(fs, sortedByDate1.ToList());
            }
            using (FileStream fs = new FileStream("AccountsSearchedByNameSurname.xml", FileMode.Create))
            {
                formatter.Serialize(fs, SearchedByNameSurname.searchByNameSurname);
            }
            using (FileStream fs = new FileStream("AccountsSearchedByBalance.xml", FileMode.Create))
            {
                formatter.Serialize(fs, SearchedByBalance.searchByBalance);
            }
            using (FileStream fs = new FileStream("AccountsSearchedByContribution.xml", FileMode.Create))
            {
                formatter.Serialize(fs, SearchedByContribution.searchByContribution);
            }
            MessageBox.Show("XML Serialization was done sucessfully!", "Accounts");
            actions.Text = "Serialization XML";
        }

        private void balanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            actions.Text = "Searching by Date";
        }

        private void contributionTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            actions.Text = "Searching by contribution";

        }

        IEnumerable<Account> sortedByDate = ListOfAccounts.accounts.OrderBy(n => n.TypeVkl);
        private void contributionTypeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "Sorting By Contribution";
            foreach (var el in sortedByDate)
            {
                form5.textBox1.Text += $"------------------------------------\r\nName:{el.MasterOfPuppets.Name}\r\nSurname:{el.MasterOfPuppets.Surname}\r\nDate Of Birth:{el.MasterOfPuppets.DateOfBirth}\r\nID:{el.MasterOfPuppets.PasswordNumber}\r\nContribution:{el.TypeVkl}\r\nBalance:{el.Balance}\r\nSMS-Notification:{el.IsSMS}\r\nInternet-banking:{el.IsConnectInternet}\r\nDate Of Opening:{el.Datetime}\r\nNumber:{el.MyAcc}\r\n------------------------------------\r\n";
            }
            form5.Show();
            actions.Text = "Sorted By Contribution";
        }

        private void jSONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataContractJsonSerializer formatter = new DataContractJsonSerializer(typeof(List<Account>));
            DataContractJsonSerializer formatter1 = new DataContractJsonSerializer(typeof(IEnumerable<Account>));
            using (FileStream fs = new FileStream("AccountsSortedByContribution.json", FileMode.Create))
            {
                formatter1.WriteObject(fs, sortedByDate);
            }
            using (FileStream fs = new FileStream("AccountsSortedByDate.json", FileMode.Create))
            {
                formatter1.WriteObject(fs, sortedByDate1);
            }
            using (FileStream fs = new FileStream("AccountsSearchedByNameSurname.json", FileMode.Create))
            {
                formatter.WriteObject(fs, SearchedByNameSurname.searchByNameSurname);
            }
            using (FileStream fs = new FileStream("AccountsSearchedByBalance.json", FileMode.Create))
            {
                formatter.WriteObject(fs, SearchedByBalance.searchByBalance);
            }
            using (FileStream fs = new FileStream("AccountsSearchedByContribution.json", FileMode.Create))
            {
                formatter.WriteObject(fs, SearchedByContribution.searchByContribution);
            }
            MessageBox.Show("Json Serialization was done sucessfully!", "Accounts");
            actions.Text = "Serialization JSON";
        }
        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }
        private void sortedByContributionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "History";
            XmlSerializer formatter = new XmlSerializer(typeof(List<Account>));
            using (FileStream fs = new FileStream("AccountsSortedByContribution.xml", FileMode.OpenOrCreate))
            {
                List<Account> newAccounts = formatter.Deserialize(fs) as List<Account>;
                foreach (var acc in newAccounts)
                {
                    form5.textBox1.Text += $"------------------------------------\r\nName:{acc.MasterOfPuppets.Name}\r\nSurname:{acc.MasterOfPuppets.Surname}\r\nDate Of Birth:{acc.MasterOfPuppets.DateOfBirth}\r\nID:{acc.MasterOfPuppets.PasswordNumber}\r\nContribution:{acc.TypeVkl}\r\nBalance:{acc.Balance}\r\nSMS-Notification:{acc.IsSMS}\r\nInternet-banking:{acc.IsConnectInternet}\nNumber:{acc.MyAcc}\r\n------------------------------------\r\n";
                }
            }
            form5.Show();
            actions.Text = "Sorted By Contribution";
        }

        private void sortedByDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "History";
            XmlSerializer formatter = new XmlSerializer(typeof(List<Account>));
            using (FileStream fs = new FileStream("AccountsSortedByDate.xml", FileMode.OpenOrCreate))
            {
                List<Account> newAccounts = formatter.Deserialize(fs) as List<Account>;
                foreach (var acc in newAccounts)
                {
                    form5.textBox1.Text += $"------------------------------------\r\nName:{acc.MasterOfPuppets.Name}\r\nSurname:{acc.MasterOfPuppets.Surname}\r\nDate Of Birth:{acc.MasterOfPuppets.DateOfBirth}\r\nID:{acc.MasterOfPuppets.PasswordNumber}\r\nContribution:{acc.TypeVkl}\r\nBalance:{acc.Balance}\r\nSMS-Notification:{acc.IsSMS}\r\nInternet-banking:{acc.IsConnectInternet}\nNumber:{acc.MyAcc}\r\n------------------------------------\r\n";
                }
            }
            form5.Show();
            actions.Text = "Sorted By Date";
        }

        private void searchedByToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "History";
            XmlSerializer formatter = new XmlSerializer(typeof(List<Account>));
            using (FileStream fs = new FileStream("AccountsSearchedByNameSurname.xml", FileMode.OpenOrCreate))
            {
                List<Account> newAccounts = formatter.Deserialize(fs) as List<Account>;
                foreach (var acc in newAccounts)
                {
                    form5.textBox1.Text += $"------------------------------------\r\nName:{acc.MasterOfPuppets.Name}\r\nSurname:{acc.MasterOfPuppets.Surname}\r\nDate Of Birth:{acc.MasterOfPuppets.DateOfBirth}\r\nID:{acc.MasterOfPuppets.PasswordNumber}\r\nContribution:{acc.TypeVkl}\r\nBalance:{acc.Balance}\r\nSMS-Notification:{acc.IsSMS}\r\nInternet-banking:{acc.IsConnectInternet}\nNumber:{acc.MyAcc}\r\n------------------------------------\r\n";
                }
            }
            form5.Show();
            actions.Text = "Searched By Name/Surname";
        }

        private void searchedByBalanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "History";
            XmlSerializer formatter = new XmlSerializer(typeof(List<Account>));
            using (FileStream fs = new FileStream("AccountsSearchedByBalance.xml", FileMode.OpenOrCreate))
            {
                List<Account> newAccounts = formatter.Deserialize(fs) as List<Account>;
                foreach (var acc in newAccounts)
                {
                    form5.textBox1.Text += $"------------------------------------\r\nName:{acc.MasterOfPuppets.Name}\r\nSurname:{acc.MasterOfPuppets.Surname}\r\nDate Of Birth:{acc.MasterOfPuppets.DateOfBirth}\r\nID:{acc.MasterOfPuppets.PasswordNumber}\r\nContribution:{acc.TypeVkl}\r\nBalance:{acc.Balance}\r\nSMS-Notification:{acc.IsSMS}\r\nInternet-banking:{acc.IsConnectInternet}\nNumber:{acc.MyAcc}\r\n------------------------------------\r\n";
                }
            }
            form5.Show();
            actions.Text = "Sorted By Balance";
        }

        private void searchedByContributionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "History";
            XmlSerializer formatter = new XmlSerializer(typeof(List<Account>));
            using (FileStream fs = new FileStream("AccountsSearchedByContribution.xml", FileMode.OpenOrCreate))
            {
                List<Account> newAccounts = formatter.Deserialize(fs) as List<Account>;
                foreach (var acc in newAccounts)
                {
                    form5.textBox1.Text += $"------------------------------------\r\nName:{acc.MasterOfPuppets.Name}\r\nSurname:{acc.MasterOfPuppets.Surname}\r\nDate Of Birth:{acc.MasterOfPuppets.DateOfBirth}\r\nID:{acc.MasterOfPuppets.PasswordNumber}\r\nContribution:{acc.TypeVkl}\r\nBalance:{acc.Balance}\r\nSMS-Notification:{acc.IsSMS}\r\nInternet-banking:{acc.IsConnectInternet}\nNumber:{acc.MyAcc}\r\n------------------------------------\r\n";
                }
            }
            form5.Show();
            actions.Text = "Searched By Contribution";
        }

        private void sortedByContributionToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "History";
            DataContractJsonSerializer formatter = new DataContractJsonSerializer(typeof(IEnumerable<Account>));
            using (FileStream fs = new FileStream("AccountsSortedByContribution.json", FileMode.OpenOrCreate))
            {
                IEnumerable<Account> newAccs = (IEnumerable<Account>)formatter.ReadObject(fs);
                foreach (var acc in newAccs)
                {
                    form5.textBox1.Text += $"------------------------------------\r\nName:{acc.MasterOfPuppets.Name}\r\nSurname:{acc.MasterOfPuppets.Surname}\r\nDate Of Birth:{acc.MasterOfPuppets.DateOfBirth}\r\nID:{acc.MasterOfPuppets.PasswordNumber}\r\nContribution:{acc.TypeVkl}\r\nBalance:{acc.Balance}\r\nSMS-Notification:{acc.IsSMS}\r\nInternet-banking:{acc.IsConnectInternet}\nNumber:{acc.MyAcc}\r\n------------------------------------\r\n";
                }
            }      
            form5.Show();
            actions.Text = "Sorted By Contribution";
        }

        private void sortedByDateToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "History";
            DataContractJsonSerializer formatter = new DataContractJsonSerializer(typeof(IEnumerable<Account>));
            using (FileStream fs = new FileStream("AccountsSortedByDate.json", FileMode.OpenOrCreate))
            {
                IEnumerable<Account> newAccs = (IEnumerable<Account>)formatter.ReadObject(fs);
                foreach (var acc in newAccs)
                {
                    form5.textBox1.Text += $"------------------------------------\r\nName:{acc.MasterOfPuppets.Name}\r\nSurname:{acc.MasterOfPuppets.Surname}\r\nDate Of Birth:{acc.MasterOfPuppets.DateOfBirth}\r\nID:{acc.MasterOfPuppets.PasswordNumber}\r\nContribution:{acc.TypeVkl}\r\nBalance:{acc.Balance}\r\nSMS-Notification:{acc.IsSMS}\r\nInternet-banking:{acc.IsConnectInternet}\nNumber:{acc.MyAcc}\r\n------------------------------------\r\n";
                }
            }
            form5.Show();
            actions.Text = "Sorted By Date";
        }

        private void searchedByNameSurnameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "History";
            DataContractJsonSerializer formatter = new DataContractJsonSerializer(typeof(List<Account>));
            using (FileStream fs = new FileStream("AccountsSearchedByNameSurname.json", FileMode.OpenOrCreate))
            {
                List<Account> newAccs = (List<Account>)formatter.ReadObject(fs);
                foreach (var acc in newAccs)
                {
                    form5.textBox1.Text += $"------------------------------------\r\nName:{acc.MasterOfPuppets.Name}\r\nSurname:{acc.MasterOfPuppets.Surname}\r\nDate Of Birth:{acc.MasterOfPuppets.DateOfBirth}\r\nID:{acc.MasterOfPuppets.PasswordNumber}\r\nContribution:{acc.TypeVkl}\r\nBalance:{acc.Balance}\r\nSMS-Notification:{acc.IsSMS}\r\nInternet-banking:{acc.IsConnectInternet}\nNumber:{acc.MyAcc}\r\n------------------------------------\r\n";
                }
            }
            form5.Show();
            actions.Text = "Searched By Name";
        }

        private void searchedByContributionToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "History";
            DataContractJsonSerializer formatter = new DataContractJsonSerializer(typeof(List<Account>));
            using (FileStream fs = new FileStream("AccountsSearchedByContribution.json", FileMode.OpenOrCreate))
            {
                List<Account> newAccs = (List<Account>)formatter.ReadObject(fs);
                foreach (var acc in newAccs)
                {
                    form5.textBox1.Text += $"------------------------------------\r\nName:{acc.MasterOfPuppets.Name}\r\nSurname:{acc.MasterOfPuppets.Surname}\r\nDate Of Birth:{acc.MasterOfPuppets.DateOfBirth}\r\nID:{acc.MasterOfPuppets.PasswordNumber}\r\nContribution:{acc.TypeVkl}\r\nBalance:{acc.Balance}\r\nSMS-Notification:{acc.IsSMS}\r\nInternet-banking:{acc.IsConnectInternet}\nNumber:{acc.MyAcc}\r\n------------------------------------\r\n";
                }
            }
            form5.Show();
            actions.Text = "Searched By Contribution";
        }

        private void searchedByBalanceToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "History";
            DataContractJsonSerializer formatter = new DataContractJsonSerializer(typeof(List<Account>));
            using (FileStream fs = new FileStream("AccountsSearchedByBalance.json", FileMode.OpenOrCreate))
            {
                List<Account> newAccs = (List<Account>)formatter.ReadObject(fs);
                foreach (var acc in newAccs)
                {
                    form5.textBox1.Text += $"------------------------------------\r\nName:{acc.MasterOfPuppets.Name}\r\nSurname:{acc.MasterOfPuppets.Surname}\r\nDate Of Birth:{acc.MasterOfPuppets.DateOfBirth}\r\nID:{acc.MasterOfPuppets.PasswordNumber}\r\nContribution:{acc.TypeVkl}\r\nBalance:{acc.Balance}\r\nSMS-Notification:{acc.IsSMS}\r\nInternet-banking:{acc.IsConnectInternet}\nNumber:{acc.MyAcc}\r\n------------------------------------\r\n";
                }
            }
            form5.Show();
            actions.Text = "Searched By Balance";
        }

        private void dateToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "Sorted By Date";
            foreach (var el in sortedByDate1)
            {
                form5.textBox1.Text += $"------------------------------------\r\nName:{el.MasterOfPuppets.Name}\r\nSurname:{el.MasterOfPuppets.Surname}\r\nDate Of Birth:{el.MasterOfPuppets.DateOfBirth}\r\nID:{el.MasterOfPuppets.PasswordNumber}\r\nContribution:{el.TypeVkl}\r\nBalance:{el.Balance}\r\nSMS-Notification:{el.IsSMS}\r\nInternet-banking:{el.IsConnectInternet}\nNumber:{el.MyAcc}\r\n------------------------------------\r\n";
            }
            form5.Show();
            actions.Text = "Sorted By Date";
        }

        private void contributionTypeToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Text = "Sorted By Contribution";
            foreach (var el in sortedByDate)
            {
                form5.textBox1.Text += $"------------------------------------\r\nName:{el.MasterOfPuppets.Name}\r\nSurname:{el.MasterOfPuppets.Surname}\r\nDate Of Birth:{el.MasterOfPuppets.DateOfBirth}\r\nID:{el.MasterOfPuppets.PasswordNumber}\r\nContribution:{el.TypeVkl}\r\nBalance:{el.Balance}\r\nSMS-Notification:{el.IsSMS}\r\nInternet-banking:{el.IsConnectInternet}\r\nDate Of Opening:{el.Datetime}\r\nNumber:{el.MyAcc}\r\n------------------------------------\r\n";
            }
            form5.Show();
            actions.Text = "Sorted By Contribution";
        }

        private void contributionTypeToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            actions.Text = "Contribution";
        }

        private void nameSurnameToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            actions.Text = "Surname";
        }

        private void balanceToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            actions.Text = "Balance";
        }

        private void showBottomMenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!toolStrip1.Visible)
            {
                showBottomMenuToolStripMenuItem.Enabled = true;
                toolStrip1.Visible = (toolStrip1.Visible) ? false : true;
                actions.Text = "Dissapear";
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            ListOfAccounts.accounts.Clear();
            MessageBox.Show("The collection was cleared");
            actions.Text = "Deleted";
            toolStripLabel1.Text = ListOfAccounts.accounts.Count.ToString() + " object(s)";
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox6.Text = "";
            comboBox1.Text = "";
            dateTimePicker1.Value = DateTime.Now;
            dateTimePicker2.Value = DateTime.Now;
            foreach (int i in IB.CheckedIndices)
            {
                IB.SetItemCheckState(i, CheckState.Unchecked);
            }
            foreach (int i in checkedListBox1.CheckedIndices)
            {
                checkedListBox1.SetItemCheckState(i, CheckState.Unchecked);
            }
            actions.Text = "Cleared";
        }
        private void nextButton_Click(object sender, EventArgs e)
        {
            if (listUR.Count > 0)
            {
                var returned = listUR.Pop();
                ListOfAccounts.accounts.Add(returned);
                toolStripLabel1.Text = ListOfAccounts.accounts.Count.ToString() + " object(s)";
            }
            else
            {
                MessageBox.Show("Cannot");
            }
        }
        private void backButton_Click(object sender, EventArgs e)
        {
            if(ListOfAccounts.accounts.Count > 0)
            {
                listUR.Push(ListOfAccounts.accounts.Last());
                ListOfAccounts.accounts.RemoveAt(ListOfAccounts.accounts.Count-1);
                toolStripLabel1.Text = ListOfAccounts.accounts.Count.ToString() + " object(s)";
            }
            else
            {
                MessageBox.Show("You're kidding?");
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            actions.Text = "Set Name";
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            actions.Text = "Set Surname";
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            actions.Text = "Set ID Password";
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            actions.Text = "Set number";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            actions.Text = "Set Contribution";
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            actions.Text = "Set Cost";
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            actions.Text = "Set BirthDate";
        }

        private void IB_SelectedIndexChanged(object sender, EventArgs e)
        {
            actions.Text = "Select Internet-banking";
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            actions.Text = "Select SMS";
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            actions.Text = "Set Account Date";
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            toolStrip1.Visible = (toolStrip1.Visible) ? false : true;
            toolStripButton1.Visible = (toolStripButton1.Visible) ? false : true;
            actions.Text = "Show up";
        }
    }
}
