﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            Text = "Search by contribution type";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var el in ListOfAccounts.accounts)
            {
                if (comboBox1.Text == el.TypeVkl)
                {
                    MessageBox.Show($"Name:{el.MasterOfPuppets.Name}\nSurname:{el.MasterOfPuppets.Surname}\n" +
                        $"Date Of Birth:{el.MasterOfPuppets.DateOfBirth}\nID:{el.MasterOfPuppets.PasswordNumber}\n" +
                        $"Contribution:{el.TypeVkl}\nBalance:{el.Balance}$\nSMS-Notification:{el.IsSMS}\nInternet-banking:{el.IsConnectInternet}\n" +
                        $"Number:{el.MyAcc}", $"{el.MasterOfPuppets.Name} {el.MasterOfPuppets.Surname}");
                    SearchedByContribution.searchByContribution.Add(el);
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
