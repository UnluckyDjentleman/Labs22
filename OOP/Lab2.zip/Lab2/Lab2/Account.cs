﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    [Serializable]
    public class Account
    {
        public long MyAcc { get; set; }//acc number
        public string TypeVkl { get; set; }//type of vklad
        public double Balance { get; set; }//balance
        public string Datetime { get; set; }//Date
        public string IsSMS { get; set; }//Is SMS - notifications connected
        public string IsConnectInternet { get; set; }//IS Internet banking connected
        public Master MasterOfPuppets;
        public Account(long myAcc, string typeVkl, double balance,string dateTime, string isSMS,string isConnectInternet,Master master)
        {
            MyAcc = myAcc;
            TypeVkl = typeVkl;
            Balance = balance;
            Datetime = dateTime;
            IsSMS = isSMS;
            IsConnectInternet = isConnectInternet;
            MasterOfPuppets = master;
        }
        public Account()
        {
            MyAcc = 0;
            TypeVkl = "";
            Balance = 0.0;
            Datetime = "";
            IsSMS = "";
            IsConnectInternet = "";
            MasterOfPuppets = new Master();
        }
    }
}
