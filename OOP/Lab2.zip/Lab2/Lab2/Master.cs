﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    [Serializable]
    public class Master
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string DateOfBirth { get; set; }
        public string PasswordNumber { get; set; }
        public Master(string name,string surname,string dateOfBirth,string passwordNum)
        {
            Name = name;
            Surname = surname;
            DateOfBirth = dateOfBirth;
            PasswordNumber = passwordNum;
        }
        public Master() { }
    }
}
