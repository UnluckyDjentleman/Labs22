﻿using System;
using System.IO;
using System.Xml.Serialization;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
        private void IB_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }
        List<Account> accounts = new List<Account>();
        Account emptyAcc = new Account();
        public bool ValidFields()//validation of fields
        {
            Regex regexName = new Regex(@"^[A-Z][a-z]+(-'[A-Z][a-z]+)?$");
            Regex regexPasswordID = new Regex(@"^([0-9]{7})+[A-Z]+([0-9]{3})+([A-Z]{2})+[0-9]");
            Match matchName = regexName.Match(textBox1.Text);
            Match matchSurname = regexName.Match(textBox2.Text);
            Match matchPasswordID = regexPasswordID.Match(textBox3.Text);
            if (!matchName.Success || !matchSurname.Success)
            {
                MessageBox.Show("Name&Surname shouldn't consist numbers or such symbols as !@#$%^&*()></?.,№+=~`");
                return false;
            }
            if (!matchPasswordID.Success)
            {
                MessageBox.Show("Wrong ID.");
                return false;
            }
            if (textBox6.Text.Length != 10)
            {
                MessageBox.Show("Number of contribution should have 10 numbers");
                return false;
            }
            try
            {
                new DataTable().Compute(textBox6.Text, null);
            }
            catch(Exception e)
            {
                MessageBox.Show("Number of contribution should have 10 numbers");
                return false;
            }
            if (comboBox1.Text == "")
            {
                MessageBox.Show("You forgot to choose contribution!");
                return false;
            }
            try
            {
                if (textBox4.Text.Contains("."))
                {
                    textBox4.Text=textBox4.Text.Replace(".",",");
                }
                double cost = Convert.ToDouble(textBox4.Text);
            }
            catch (Exception e)
            {
                MessageBox.Show("Wrong sum!");
                return false;
            }
            if (IB.CheckedItems.Count == 0)
            {
                MessageBox.Show($"You missed field {label9.Text}");
                return false;
            }
            else if (IB.CheckedItems.Count>1)
            {
                MessageBox.Show($"You can choose only 1");
                return false;
            }
            if (checkedListBox1.CheckedItems.Count == 0)
            {
                MessageBox.Show($"You missed field {label10.Text}");
                return false;
            }
            else if (checkedListBox1.CheckedItems.Count > 1)
            {
                MessageBox.Show($"You can choose only 1");
                return false;
            }
            if (dateTimePicker1.Value.Year >= dateTimePicker2.Value.Year)
            {
                MessageBox.Show($"Wrong format of date");
                return false;
            }
            if(dateTimePicker2.Value.Year - dateTimePicker1.Value.Year < 18)
            {
                MessageBox.Show($"You should be 18");
                return false;
            }
            return true;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string iSMS = "";
            string iBank = "";
            if (ValidFields())
            {
                string dOB = dateTimePicker1.Value.Day.ToString() + "." + dateTimePicker1.Value.Month.ToString() + "." + dateTimePicker1.Value.Year.ToString();
                string dOO = dateTimePicker2.Value.Day.ToString() + "." + dateTimePicker2.Value.Month.ToString() + "." + dateTimePicker2.Value.Year.ToString();
                Master dungeonMaster = new Master(textBox1.Text, textBox2.Text, dOB, textBox3.Text);
                if (IB.GetItemChecked(0))
                {
                    iBank = IB.Items[0].ToString();
                }
                else if (IB.GetItemChecked(1))
                {
                    iBank = IB.Items[1].ToString();
                }
                if (checkedListBox1.GetItemChecked(0))
                {
                    iSMS = checkedListBox1.Items[0].ToString();
                }
                else if (checkedListBox1.GetItemChecked(1))
                {
                    iSMS = checkedListBox1.Items[1].ToString();
                }
                emptyAcc = new Account(Convert.ToInt64(textBox6.Text), comboBox1.Text, Convert.ToDouble(textBox4.Text),
                    dOO,
                    iSMS, iBank, dungeonMaster);
                accounts.Add(emptyAcc);
                MessageBox.Show("Congratulations! Your account is valid and info added to object!","Accounts");
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox6.Text = "";
                comboBox1.Text = "";
                dateTimePicker1.Value = DateTime.Now;
                dateTimePicker2.Value = DateTime.Now;
                foreach (int i in IB.CheckedIndices)
                {
                    IB.SetItemCheckState(i, CheckState.Unchecked);
                }
                foreach (int i in checkedListBox1.CheckedIndices)
                {
                    checkedListBox1.SetItemCheckState(i, CheckState.Unchecked);
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            XmlSerializer formatter = new XmlSerializer(typeof(List<Account>));
            using (FileStream fs = new FileStream("Accounts.xml", FileMode.Create))
            {
                formatter.Serialize(fs, accounts);
            }
            MessageBox.Show("XML Serialization was done sucessfully!", "Accounts");
        }

        private void label_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Text = "History";
            XmlSerializer formatter = new XmlSerializer(typeof(List<Account>));
            using (FileStream fs = new FileStream("Accounts.xml", FileMode.OpenOrCreate))
            {
                List<Account>newAccounts=formatter.Deserialize(fs) as List<Account>;
                foreach(var acc in newAccounts)
                {
                    form2.textBox1.Text+=$"------------------------------------\r\nName:{acc.MasterOfPuppets.Name}\r\nSurname:{acc.MasterOfPuppets.Surname}\r\nDate Of Birth:{acc.MasterOfPuppets.DateOfBirth}\r\nID:{acc.MasterOfPuppets.PasswordNumber}\r\nContribution:{acc.TypeVkl}\r\nBalance:{acc.Balance}\r\nSMS-Notification:{acc.IsSMS}\r\nInternet-banking:{acc.IsConnectInternet}\r\nNumber:{acc.MyAcc}\r\n------------------------------------\r\n";
                }
            }
            form2.Show();
        }
    }
}
