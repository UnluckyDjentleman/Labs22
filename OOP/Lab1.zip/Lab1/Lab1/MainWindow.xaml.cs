﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            foreach(UIElement el in Calc.Children)
            {
                if(el is Button)
                {
                    ((Button)el).Click += Button_Click;
                }
            }
        }
        Stack<string> calcMem = new Stack<string>();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button b = (Button)sender;
                if (textBox.Text.Contains(","))
                {
                    textBox.Text = textBox.Text.Replace(",", ".");
                }
                switch (b.Content.ToString())
                {
                    case "C": textBox.Text = ""; break;
                    case "cos":
                        {
                        try
                        {
                            textBox.Text = Math.Cos(Math.PI * Convert.ToDouble(new DataTable().Compute(textBox.Text, null).ToString()) / 180).ToString();
                        }
                        catch (SyntaxErrorException exc)
                        {
                            MessageBox.Show(exc.Message);
                        }
                        }
                        break;
                    case "sin":
                        {
                        try
                        {
                            textBox.Text = Math.Sin(Math.PI * Convert.ToDouble(new DataTable().Compute(textBox.Text, null).ToString()) / 180).ToString();
                        }
                        catch (SyntaxErrorException exc)
                        {
                            MessageBox.Show(exc.Message);
                        }
                    }
                        break;
                    case "tan":
                        {
                        try
                        {
                            textBox.Text = Math.Tan(Math.PI * Convert.ToDouble(new DataTable().Compute(textBox.Text, null).ToString()) / 180).ToString();
                        }
                        catch (SyntaxErrorException exc)
                        {
                            MessageBox.Show(exc.Message);
                        }
                    }
                        break;
                    case "ctg":
                        {
                        try
                        {
                            textBox.Text = (1 / Math.Tan(Math.PI * Convert.ToDouble(new DataTable().Compute(textBox.Text, null).ToString()) / 180)).ToString();
                        }
                        catch (SyntaxErrorException exc)
                        {
                            MessageBox.Show(exc.Message);
                        }
                    }
                        break;
                    case "cubr":
                        {
                        try
                        {
                            textBox.Text = Math.Pow(Convert.ToDouble(new DataTable().Compute(textBox.Text, null).ToString()), Math.Pow(3, -1)).ToString();
                        }
                        catch (SyntaxErrorException exc)
                        {
                            MessageBox.Show(exc.Message);
                        }
                    }
                        break;
                    case "sqrt":
                        {
                        try
                        {
                            textBox.Text = Math.Sqrt(Convert.ToDouble(new DataTable().Compute(textBox.Text, null).ToString())).ToString();
                        }
                        catch (SyntaxErrorException exc)
                        {
                            MessageBox.Show(exc.Message);
                        }
                    }
                        break;
                    case "=":
                        {
                        try
                        {
                            if (textBox.Text.Contains("^"))
                            {
                                try
                                {
                                    string tempFirst = textBox.Text.Substring(0, textBox.Text.IndexOf("^"));
                                    string tempSec = textBox.Text.Substring(textBox.Text.IndexOf("^") + 1);
                                    if (tempFirst.Contains(".")|| tempSec.Contains("."))
                                    {
                                        tempFirst=tempFirst.Replace(".", ",");
                                        tempSec = tempSec.Replace(".", ",");
                                    }
                                    double numInRaise = Convert.ToDouble(tempFirst);
                                    double numPower = Convert.ToDouble(tempSec);
                                    textBox.Text = Math.Pow(numInRaise, numPower).ToString();
                                }
                                catch(Exception exc)
                                {
                                    MessageBox.Show("Invalid input!");
                                }
                            }
                            else textBox.Text = new DataTable().Compute(textBox.Text, null).ToString();
                        }
                        catch(SyntaxErrorException exc)
                        {
                            MessageBox.Show(exc.Message);
                        }
                        }
                        break;
                    case "MK":
                        {
                        if (textBox.Text != "")
                            {
                            calcMem.Push(new DataTable().Compute(textBox.Text, null).ToString());
                            }
                            else
                            {
                                MessageBox.Show("You should enter the value!");
                            }
                        }
                        break;
                    case "MD":
                        {
                            if (calcMem.Count != 0)
                            {
                                textBox.Text += calcMem.Pop();
                            }
                            else
                            {
                                MessageBox.Show("Memory is empty");
                            }
                        }
                        break;
                    case "^":
                    {
                        textBox.Text += b.Content.ToString();
                    }
                    break;
                    default: textBox.Text += b.Content.ToString(); break;
                }
            
        }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
